/*
 * HeadlinesMgr.java
 *
 * Created on May 21, 2005, 6:49 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour;

import com.hiatus.UText;
import com.sun.org.apache.xpath.internal.XPathAPI;
import de.nava.informa.core.*;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.xml.parsers.*;
import javax.xml.transform.TransformerException;
import org.apache.log4j.Logger;
import org.bloggers4labour.conf.Configuration;
import org.bloggers4labour.feed.FeedList;
import org.bloggers4labour.headlines.*;
import org.bloggers4labour.xml.XMLUtils;
import org.w3c.dom.*;
import org.w3c.dom.traversal.NodeIterator;
import static org.bloggers4labour.Constants.*;

/**
 *
 * @author andrewre
 */
public class HeadlinesMgr
{
//	private static Headlines		s_48Hour_Headlines;
	private static Headlines		s_24Hour_Headlines;

	private static Headlines		s_MainRSSFeed_Headlines;
	private static Headlines		s_EmailPosts_Headlines;
	private static Headlines		s_IndexablePosts_Headlines;
	private static Headlines		s_RecentPosts_Headlines;
	private static Headlines		s_Comments_Headlines;	// (AGR) 29 Nov 2005

	private static List<Headlines>		s_HeadlinesList = new CopyOnWriteArrayList<Headlines>();  // (AGR) 29 May 2005. Was ArrayList
	private static Logger			s_HeadlinesMgr_Logger = Logger.getLogger("Main");

	/*******************************************************************************
	*******************************************************************************/
	public synchronized static void setUpDefaults()
	{
		Configuration		theConf = Configuration.getInstance();
		DocumentBuilderFactory	docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder		docBuilder;

		try
		{
			docBuilder = docFactory.newDocumentBuilder();

			Document	theHDoc = docBuilder.parse( theConf.findFile("headlines.xml") );
			Element		docElem = theHDoc.getDocumentElement();

			String		rss_feed_ID = XMLUtils.getIDValue( docElem, "rss_feed");
			String		email_ID = XMLUtils.getIDValue( docElem, "email");
			String		index_ID = XMLUtils.getIDValue( docElem, "index");
			String		recent_ID = XMLUtils.getIDValue( docElem, "recent");
			String		comments_ID = XMLUtils.getIDValue( docElem, "comments");    // (AGR) 29 Nov 2005

			NodeList	headsNodes = docElem.getElementsByTagName("headlines");

			if ( headsNodes != null)
			{
				for ( int i = 0; i < headsNodes.getLength(); i++)
				{
					Element		e = (Element) headsNodes.item(i);
					String		ourIDStr = XMLUtils.getNodeIDValue(e);
					NodeList	nl = e.getChildNodes();
					String		theName = null;
					String		theAllowedItems = null;
					long		theMinValue = -1;
					long		theMaxValue = -1;
					boolean		gotError = false;
					boolean		wantComments = false;
					boolean		wantPosts = false;

					for ( int j = 0; j < nl.getLength(); j++)
					{
						Node	n = nl.item(j);

						if (n.getNodeName().equals("name"))
						{
							theName = n.getFirstChild().getNodeValue();
						}
						else if (n.getNodeName().equals("items"))	// (AGR) 29 Nov 2005
						{
							theAllowedItems = n.getFirstChild().getNodeValue();
							if (UText.isNullOrBlank(theAllowedItems))
							{
								gotError = true;
								break;
							}

							////////////////////////  Look for a usable value...

							if (theAllowedItems.equalsIgnoreCase("POSTS"))
							{
								wantPosts = true;
							}
							else if (theAllowedItems.equalsIgnoreCase("COMMENTS"))
							{
								wantComments = true;
							}
							else
							{
								gotError = true;
								break;
							}
						}
						else if (n.getNodeName().equals("minAgeMillis"))
						{
							theMinValue = Long.parseLong( n.getFirstChild().getNodeValue() );
						}
						else if (n.getNodeName().equals("maxAgeMillis"))
						{
							theMaxValue = Long.parseLong( n.getFirstChild().getNodeValue() );
							if ( theMaxValue <= 0L)
							{
								gotError = true;
								break;
							}
						}
					}

					////////////////////////////////////////////////////////////////

					if ( gotError || theMinValue >= theMaxValue)
					{
						continue;
					}
					
					////////////////////////////////////////////////////////////////

					Headlines	h = new Headlines( theName, theMinValue, theMaxValue);

					h.setAllowPosts(wantPosts);
					h.setAllowComments(wantComments);

					////////////////////////////////////////////////////////////////

					NodeIterator	ni = XPathAPI.selectNodeIterator( e, "handlers/class");
					Node		handlerNode;
					String		theClassName;

					while (( handlerNode = ni.nextNode()) != null)
					{
						try
						{
							theClassName = handlerNode.getFirstChild().getNodeValue();

							Class	clazz = Class.forName(theClassName);

							h.addHandler((Handler) clazz.newInstance());
						}
						catch (Exception e2)
						{
							s_HeadlinesMgr_Logger.error( "handlers...", e2);
						}
					}

					////////////////////////////////////////////////////////////////

					if ( ourIDStr != null)
					{
						if ( ourIDStr.equals(rss_feed_ID) && s_MainRSSFeed_Headlines == null)
						{
							s_MainRSSFeed_Headlines = h;
						}

						if ( ourIDStr.equals(email_ID) && s_EmailPosts_Headlines == null)
						{
							s_EmailPosts_Headlines = h;
						}

						if ( ourIDStr.equals(index_ID) && s_IndexablePosts_Headlines == null)
						{
							s_IndexablePosts_Headlines = h;
						}

						if ( ourIDStr.equals(recent_ID) && s_RecentPosts_Headlines == null)
						{
							s_RecentPosts_Headlines = h;
						}

						if ( ourIDStr.equals(comments_ID) && s_Comments_Headlines == null)	// (AGR) 29 Nov 2005
						{
							s_Comments_Headlines = h;
						}
					}

					////////////////////////////////////////////////////////////////

					if ( theMinValue <= 0 && theMaxValue == ONE_DAY_MSECS && s_24Hour_Headlines == null)
					{
						s_24Hour_Headlines = h;
					}

					////////////////////////////////////////////////////////////////

					s_HeadlinesList.add(h);
				}
			}

		}
		catch (Exception e)
		{
			s_HeadlinesMgr_Logger.error( "setUpDefaults()", e);
		}

		////////////////////////////////////////////////////////////////

/*		s_24Hour_Headlines = new Headlines( "One day", 1 - ONE_DAY_MSECS, ONE_DAY_MSECS);
		s_HeadlinesList.add(s_24Hour_Headlines);

		s_48Hour_Headlines = new Headlines( "Two day", 1 - ONE_DAY_MSECS, 2 * ONE_DAY_MSECS);
		s_48Hour_Headlines.addHandler( new SampleExpiryHandler() );
		s_HeadlinesList.add(s_48Hour_Headlines);

		////////////////////////////////////////////////////////////////

		s_MainRSSFeed_Headlines = s_24Hour_Headlines;
		s_EmailPosts_Headlines = s_48Hour_Headlines;
		s_RecentPosts_Headlines = s_48Hour_Headlines;
		s_IndexablePosts_Headlines = s_48Hour_Headlines;
*/
		////////////////////////////////////////////////////////////////

		FeedList.getInstance().addObserver( new PublishSnapshotEvent() );
	}

	/*******************************************************************************
	*******************************************************************************/
	public static int getHeadlinesCount()
	{
		return s_HeadlinesList.size();
	}

	/*******************************************************************************
	*******************************************************************************/
	public static Headlines getMainRSSFeedInstance()
	{
		return s_MainRSSFeed_Headlines;
	}

	/*******************************************************************************
	*******************************************************************************/
	public static Headlines getRecentPostsInstance()
	{
		return s_RecentPosts_Headlines;
	}

	/*******************************************************************************
	*******************************************************************************/
	public static Headlines getCommentsInstance()
	{
		return s_Comments_Headlines;
	}

	/*******************************************************************************
	*******************************************************************************/
	public static Headlines getEmailPostsInstance()
	{
		return s_EmailPosts_Headlines;
	}

	/*******************************************************************************
	*******************************************************************************/
	public static Headlines getIndexablePostsInstance()
	{
		return s_IndexablePosts_Headlines;
	}

	/*******************************************************************************
	*******************************************************************************/
	public static Headlines get24HourInstance()
	{
		return s_24Hour_Headlines;
	}

	/*******************************************************************************
	*******************************************************************************/
	public static void removeFor( ChannelIF inChannel)
	{
		for ( Headlines h : s_HeadlinesList)
		{
			h.removeFor(inChannel);
		}

		// get48HourInstance().removeFor(inChannel);
		// get24HourInstance().removeFor(inChannel);
	}

	/*******************************************************************************
	*******************************************************************************/
	protected static List<Headlines> getHeadlinesList()
	{
		return s_HeadlinesList;
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized static void shutdown()
	{
		for ( Headlines h : s_HeadlinesList)
		{
			h.shutdown();
		}

		s_HeadlinesList.clear();
	}

	/*******************************************************************************
		(AGR) 19 April 2005. Publish Headlines snapshot in FeedList
		(AGR) 22 June 2005. Changed to be FeedList Observer
	*******************************************************************************/
	private static class PublishSnapshotEvent implements Observer
	{
		/*******************************************************************************
		*******************************************************************************/
		public void update( Observable o, Object arg)
		{
			Headlines	h = getMainRSSFeedInstance();

			if ( h != null)		// (AGR) 28 May 2005. Shouldn't happen, but prevent NPE
			{
				h.publishSnapshot();
			}
			else	s_HeadlinesMgr_Logger.info("Cannot write snapshot");
		}
	}
}
