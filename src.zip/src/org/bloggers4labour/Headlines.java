/*
 * Headlines.java
 *
 * Created on 12 March 2005, 02:27
 */

package org.bloggers4labour;

import com.hiatus.UDates;
import de.nava.informa.parsers.*;
import de.nava.informa.core.*;
import de.nava.informa.impl.basic.Channel;
import de.nava.informa.impl.basic.Item;
import de.nava.informa.utils.poller.*;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;
import org.apache.log4j.Logger;
import org.bloggers4labour.headlines.*;
import org.bloggers4labour.opml.OPMLGenerator;
import org.bloggers4labour.options.Options;
import org.bloggers4labour.options.TaskOptionsBeanIF;
import org.bloggers4labour.tag.Link;

/**
 *
 * @author andrewre
 */
public class Headlines implements HeadlinesIF
{
	private TreeMap<ItemIF,ItemIF>	m_Coll = new TreeMap<ItemIF,ItemIF>( new ItemsComparator() );
	private Timer			m_CleanTimer;
	private CleanerTask		m_CleanerTask;
	private String			m_HeadlinesXMLString;	// (AGR) 19 April 2005
	private long			m_MaxAgeMsecs;		// (AGR) 21 May 2005
	private long			m_MinAgeMsecs;		// (AGR) 22 May 2005
	private String			m_Name;			// (AGR) 22 May 2005
	private boolean			m_AllowPosts;		// (AGR) 29 Nov 2005
	private boolean			m_AllowComments;	// " " "

	////////////////////////////////////////////////////////////////////////  (AGR) 25-26 June 2005. Handlers

	private List<AddHandler>	m_AddHandlers = new CopyOnWriteArrayList<AddHandler>();
	private List<RemoveHandler>	m_RemoveHandlers = new CopyOnWriteArrayList<RemoveHandler>();
	private List<ExpiryHandler>	m_ExpiryHandlers = new CopyOnWriteArrayList<ExpiryHandler>();

	////////////////////////////////////////////////////////////////////////

	private static Logger		s_Headlines_Logger = Logger.getLogger("Main");

	private static ItemIF[]		s_TempArray = new ItemIF[0];

	/*******************************************************************************
	*******************************************************************************/
	public Headlines( String inName, long inMinAgeMsecs, long inMaxAgeMsecs)
	{
		m_Name = inName;
		m_MinAgeMsecs = inMinAgeMsecs;
		m_MaxAgeMsecs = inMaxAgeMsecs;
		s_Headlines_Logger.info("Headlines: created \"" + UDates.getFormattedTimeDiff(m_MaxAgeMsecs) + "\" instance, \"" + m_Name + "\".");

		m_CleanTimer = new Timer();
		m_CleanerTask = new CleanerTask( this, m_MaxAgeMsecs);

		////////////////////////////////////////////////////////////////  (AGR) 29 Nov 2005

		m_AllowPosts = true;
		m_AllowComments = false;

		////////////////////////////////////////////////////////////////

		TaskOptionsBeanIF	theOptionsBean = Options.getOptions().getHeadlinesCleanerTaskOptions();

		m_CleanTimer.scheduleAtFixedRate( m_CleanerTask,
						  theOptionsBean.getDelayMsecs(),
						  theOptionsBean.getPeriodMsecs());
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	public void setAllowPosts( boolean x)
	{
		m_AllowPosts = x;
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	public void setAllowComments( boolean x)
	{
		m_AllowComments = x;
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	public boolean allowsPosts()
	{
		return m_AllowPosts;
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	public boolean allowsComments()
	{
		return m_AllowComments;
	}

	/*******************************************************************************
	*******************************************************************************/
	public void shutdown()
	{
		if ( m_CleanTimer != null)
		{
			s_Headlines_Logger.info("Headlines: cancelling Timer: " + m_CleanTimer);

			m_CleanTimer.cancel();
			m_CleanTimer = null;
		}

		m_CleanerTask = null;

		/////////////////////////  (AGR) 13 April 2005

		if ( m_Coll != null)
		{
			m_Coll.clear();
			m_Coll = null;
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized Iterator<ItemIF> iterator()
	{
		return m_Coll.keySet().iterator();
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized ItemIF[] toArray()
	{
		if ( m_Coll == null)
			return s_TempArray;	// Shouldn't happen!

		return (ItemIF[]) m_Coll.values().toArray(s_TempArray);
	}

	/*******************************************************************************
		(AGR) 11 July 2005
	*******************************************************************************/
	public long getMaxAgeMsecs()
	{
		return m_MaxAgeMsecs;
	}

	/*******************************************************************************
		(AGR) 11 July 2005
	*******************************************************************************/
	public long getMinAgeMsecs()
	{
		return m_MinAgeMsecs;
	}

	/*******************************************************************************
	*******************************************************************************/
	public int size()
	{
		synchronized (this)
		{
			return m_Coll.size();
		}
	}

	/*******************************************************************************
		(AGR) 14 March 2005
		A Set of all the Blog URLs represented in the Headlines list
	*******************************************************************************/
	public Set getBlogs()
	{
		Set<String>	theSet = new HashSet<String>();

		synchronized (this)
		{
			for ( ItemIF theItem : m_Coll.keySet())
			{
				Object	theSite = theItem.getChannel().getSite();

				if ( theSite != null)
				{
					theSet.add( theSite.toString() );
				}
			}
		}

		return theSet;
	}

	/*******************************************************************************
		(AGR) 23 May 2005
		A count of all the Blog URLs represented in the Headlines list
	*******************************************************************************/
	public int getBlogsCount()
	{
		Set	theBlogs;

		synchronized (this)
		{
			theBlogs = getBlogs();
		}

		int	theCount = theBlogs.size();

		theBlogs.clear();

		return theCount;
	}

	/*******************************************************************************
	*******************************************************************************/
	public boolean isItemAgeOK( long inItemAgeMSecs)
	{
		return ( inItemAgeMSecs >= m_MinAgeMsecs && inItemAgeMSecs < m_MaxAgeMsecs);
	}

	/*******************************************************************************
	*******************************************************************************/
	public boolean put( ItemIF inNewItem)
	{
		if ( inNewItem == null)
		{
			return false;
		}

		////////////////////////////////////////////////////////////////

		URL	ourLink = inNewItem.getLink();
		ItemIF	theOldOneToRemove = null;

		synchronized (this)
		{
			for ( ItemIF theItem : m_Coll.keySet())
			{
				if (theItem.equals(inNewItem))	// Look for complete dupe
				{
					s_Headlines_Logger.info("put(): ignoring DUPE: " + inNewItem);
					return false;
				}

				////////////////////////////////////////////////////////  (AGR) 10 June 2005

				if ( ourLink != null)
				{
					URL	itsLink = theItem.getLink();

					if ( itsLink != null && ourLink.equals(itsLink))
					{
						// s_Headlines_Logger.info("put(): replacement entry???");
						// s_Headlines_Logger.info("NEW: " + FeedUtils.adjustTitle(inNewItem));
						// s_Headlines_Logger.info("OLD: " + FeedUtils.adjustTitle(theItem));

						if ( theOldOneToRemove == null)
						{
							theOldOneToRemove = theItem;  // to prevent ConcurrentModificationException
						}
						else
						{
							s_Headlines_Logger.warn("theOldOneToRemove is NOT null!");
						}
					}
				}
			}

			////////////////////////////////////////////////////////////////  Now remove the old version

			if ( theOldOneToRemove != null)
			{
				boolean	removedOldOK = ( _remove(theOldOneToRemove) != null);
				// s_Headlines_Logger.info("remove old OK? " + removedOldOK);
			}

			_put(inNewItem);

/*			for ( AddHandler ah : m_AddHandlers)	// FIXME. Temporary. See below!
			{
				ah.onAdd( this, inNewItem);
			}
*/		}

		///////////////////////////////  (AGR) 25 June 2005. The following needn't be synchronised
		///////////////////////////////  on this Headlines obj, so calling .size() on us within the
		///////////////////////////////  Handler may produce an 'unexpected' result, e.g. different to
		///////////////////////////////  the index size after the Item is removed. For performance reasons!

		for ( AddHandler ah : m_AddHandlers)
		{
			ah.onAdd( this, inNewItem);
		}

		return true;
	}

	/*******************************************************************************
	*******************************************************************************/
	private void _put( ItemIF inItem)
	{
		m_Coll.put( inItem, inItem);
	}

	/*******************************************************************************
	*******************************************************************************/
	private ItemIF _remove( ItemIF inItem)
	{
		ItemIF	theItem = m_Coll.remove(inItem);

		////////////////////////////////////////////////////////////////  (AGR) 25 June 2005

		for ( RemoveHandler rh : m_RemoveHandlers)
		{
			rh.onRemove( this, inItem);
		}

		return theItem;
	}

	/*******************************************************************************
		(AGR) 1 June 2005
	*******************************************************************************/
	public int countLinks()
	{
		TextCleaner	tc = new TextCleaner();
		List<Link>	theFullList;

		synchronized (this)
		{
			theFullList = _getLinks(tc);
		}

		int	theCount = theFullList.size();

		theFullList.clear();

		return theCount;
	}

	/*******************************************************************************
		(AGR) 13 April 2005
	*******************************************************************************/
	public List<Link> getLinksByName()
	{
		TextCleaner	tc = new TextCleaner();
		List<Link>	theFullList;

		synchronized (this)
		{
			theFullList = _getLinks(tc);
		}

		Collections.sort( theFullList, tc.newLinkNameSorter());

		return theFullList;
	}

	/*******************************************************************************
		(AGR) 13 April 2005
	*******************************************************************************/
	public List<Link> getLinksByURL()
	{
		TextCleaner	tc = new TextCleaner();
		List<Link>	theFullList;

		synchronized (this)
		{
			theFullList = _getLinks(tc);
		}

		Collections.sort( theFullList, tc.newLinkURLSorter());

		return theFullList;
	}

	/*******************************************************************************
		(AGR) 13 April 2005
	*******************************************************************************/
	private List<Link> _getLinks( TextCleaner inTC)
	{
		List<Link>	theFullList = new ArrayList<Link>(50);

		for ( ItemIF theItem : m_Coll.keySet())
		{
			List<Link>	theLinks = inTC.collectLinks( theItem.getDescription(), theItem.getLink());

			if ( theLinks != null)
			{
				theFullList.addAll(theLinks);
			}
		}

		return theFullList;
	}

	/*******************************************************************************
		Remove all entries in our table that come from the specified Channel
	*******************************************************************************/
	public synchronized void removeFor( ChannelIF inChannel)
	{
		List<ItemIF>	keysList = null;
		
		for ( ItemIF theItem : m_Coll.keySet())
		{
			ChannelIF	itemChannel = theItem.getChannel();

			if (itemChannel.equals(inChannel))
			{
				if ( keysList == null)
				{
					keysList = new ArrayList<ItemIF>();
				}

				keysList.add(theItem);	// do this to prevent ConcurrentModificationExceptions!
			}
		}

		////////////////////////////////////////////

		if ( keysList != null)
		{
			// s_Headlines_Logger.info("removing keys: " + keysList);

			for ( ItemIF remItem : keysList)
			{
				_remove(remItem);
			}
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public Set<Item> createSortedCollection()
	{
		return new TreeSet<Item>( new ItemsComparator() );
	}
	
	/*******************************************************************************
	*******************************************************************************/
	public String toString()
	{
		return ("Headlines \"" + m_Name + "\"");	// m_Coll.toString();
	}

	/*******************************************************************************
	*******************************************************************************/
	class CleanerTask extends ItemCleanerTask
	{
		private final Headlines	m_Parent;

		/*******************************************************************************
		*******************************************************************************/
		public CleanerTask( final Headlines inParent, long inMaxItemAgeMS)
		{
			super(inMaxItemAgeMS);

			m_Parent = inParent;
		}

		/*******************************************************************************
		*******************************************************************************/
		public void run()
		{
/*			if (Options.CLEANER_MEMORY_CHECKS)
			{
				FeedUtils.logMemory();
			}
*/
//			System.out.println("##### count = " + getBlogsCount() + ", set size = " + getBlogs().size());

			//////////////////////////////////////////////////////////////
			
			List<ItemIF>	keysList = null;
			long		currMS = System.currentTimeMillis();

			for ( ItemIF theItem : m_Coll.keySet())		// FIXME. Should this be sync-ed?
			{
				if (isOutOfDate( currMS, theItem))
				{
					if ( keysList == null)
					{
						keysList = new ArrayList<ItemIF>();
					}

					keysList.add(theItem);	// do this to prevent ConcurrentModificationExceptions!
				}
			}

			////////////////////////////////////////////

			if ( keysList != null)
			{
				// info("removing keys: " + keysList);

				synchronized (m_Parent)		// (AGR) 24 June 2005
				{
					for ( ItemIF remItem : keysList)
					{
						for ( ExpiryHandler eh : m_ExpiryHandlers)	// (AGR) 26 June 2005
						{
							eh.onExpire( m_Parent, remItem);
						}

						_remove(remItem);
					}
				}

				/////////////////////  (AGR) 23 May 2005

				keysList.clear();
				keysList = null;
			}
		}
	}

	/*******************************************************************************
		(AGR) 19 April 2005
	*******************************************************************************/
	public void publishSnapshot()
	{
		ItemIF[]	theItems = toArray();
		ResourceBundle	theBundle = ResourceBundle.getBundle("org/bloggers4labour/B4L");

		if ( theItems == null || theItems.length < 1)
		{
			s_Headlines_Logger.info( theBundle.getString("feed.generation.none"));	// (AGR) 21 May 2005
		}

		// As of 5 June 2005, we generate an empty RSS when there's no data
		// rather than just keep the existing data intact!

		////////////////////////////////////////////////////////////////

		FeedCreator	fc = new FeedCreator(s_Headlines_Logger);	// (AGR) 21 May 2005. Factored-out

		fc.createChannel( theBundle.getString("feed.headlines.name"), theBundle.getString("feed.headlines.description"), theItems);
		m_HeadlinesXMLString = fc.getString();

//		s_Headlines_Logger.info("Done snapshot: " + theItems.length);

		fc.clear();
		fc = null;	// (AGR) 23 May 2005

		theItems = null;
	}

	/*******************************************************************************
		(AGR) 19 April 2005
	*******************************************************************************/
	public String getHeadlinesXMLString()
	{
		return m_HeadlinesXMLString;
	}

	/*******************************************************************************
		(AGR) 25 June 2005
	*******************************************************************************
	public synchronized List<Long> getItemIDs()
	{
		List<Long>	ll = new ArrayList<Long>();

		for ( ItemIF theItem : m_Coll.keySet())
		{
			ll.add( theItem.getId() );
		}

		Collections.sort(ll);

		return ll;
	}/

	/*******************************************************************************
		(AGR) 10 July 2005
	*******************************************************************************/
	public void addHandler( Handler inHandler)
	{
		if ( inHandler instanceof AddHandler)
		{
			m_AddHandlers.add((AddHandler) inHandler);
		}
		else if ( inHandler instanceof RemoveHandler)
		{
			m_RemoveHandlers.add((RemoveHandler) inHandler);
		}
		else if ( inHandler instanceof ExpiryHandler)
		{
			m_ExpiryHandlers.add((ExpiryHandler) inHandler);
		}
	}
}