/*
 * FeedType.java
 *
 * Created on 02 June 2006, 22:49
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.feed;

/**
 *
 * @author andrewre
 */
public enum FeedType
{
	UNKNOWN, ATOM, RSD, RSS, FOAF
}