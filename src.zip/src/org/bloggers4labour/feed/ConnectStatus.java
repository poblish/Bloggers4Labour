/*
 * ConnectResult.java
 *
 * Created on November 30, 2005, 7:07 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.feed;

/**
 *
 * @author andrewre
 */
public enum ConnectStatus
{
	SUCCESS, TIMEOUT, FAILURE
}
