/*
 * FeedListManager.java
 *
 * Created on 19 February 2006, 12:22
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.feed;

/**
 *
 * @author andrewre
 */
public class FeedListManager
{
	/*******************************************************************************
	*******************************************************************************/
	public FeedListManager()
	{
	}
	
}
