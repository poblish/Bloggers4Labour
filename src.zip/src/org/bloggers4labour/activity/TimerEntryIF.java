/*
 * TimerEntryIF.java
 *
 * Created on 12 March 2006, 00:13
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.activity;

/**
 *
 * @author andrewre
 */
public interface TimerEntryIF
{
	public int getPostsCount();
	public int getBlogsUsed();
}
