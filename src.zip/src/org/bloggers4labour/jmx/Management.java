/*
 * Management.java
 *
 * Created on May 31, 2005, 11:23 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour.jmx;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Set;
import javax.management.*;
import org.apache.log4j.Logger;

/**
 *
 * @author andrewre
 */
public class Management
{
	private ObjectName		m_StatsObjectName;
	private Stats			m_Stats;

	private static Management	s_Instance;
	private static MBeanServer	s_Server;

	private static Logger		s_Management_Logger = Logger.getLogger("Main");

	/*******************************************************************************
	*******************************************************************************/
	public static synchronized Management getInstance()
	{
		if ( s_Instance == null)
		{
			s_Instance = new Management();
		}

		return s_Instance;
	}

	/*******************************************************************************
	*******************************************************************************/
	private Management()
	{
		try
		{
/*			ArrayList servers = MBeanServerFactory.findMBeanServer(null);

			if ( servers == null)
			{
				s_Server = (MBeanServer) servers.get(0);
			}
			else	s_Server = MBeanServerFactory.createMBeanServer();
*/
			s_Server = ManagementFactory.getPlatformMBeanServer();

			logContents();
		}
		catch (Exception e)
		{
			s_Management_Logger.error( "createMBeanServer", e);
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public Stats getStats()
	{
		return m_Stats;
	}

	/*******************************************************************************
	*******************************************************************************/
	private void logContents()
	{
		s_Management_Logger.info("mbs = " + s_Server);

		try
		{
			m_StatsObjectName = new ObjectName("org.bloggers4labour", "name", "b4lStats");
			m_Stats = new Stats();
			s_Server.registerMBean( m_Stats, m_StatsObjectName);
			
			// s_Management_Logger.info("theBean = " + m_Stats);
		}
		catch (MalformedObjectNameException e)
		{
			s_Management_Logger.error( "object name", e);
		}
		catch (InstanceAlreadyExistsException e)
		{
			// Fine, no worries...
		}
		catch (MBeanRegistrationException e)
		{
			s_Management_Logger.error( "creating bean", e);
		}
		catch (MBeanException e)
		{
			s_Management_Logger.error( "creating bean", e);
		}
		catch (NotCompliantMBeanException e)
		{
			s_Management_Logger.error( "creating bean", e);
		}

		////////////////////////////////////////////////////////////////

		// s_Management_Logger.info("count = " + s_Server.getMBeanCount());

/*		Set	theSet = s_Server.queryNames( null, null);
		s_Management_Logger.info("set = " + theSet);

 		for ( Object o : theSet)
		{
			ObjectName	on = (ObjectName) o;

			try
			{
				s_Management_Logger.info("MBean = " + s_Server.getObjectInstance(on));
			}
			catch (InstanceNotFoundException e)
			{
				s_Management_Logger.error( "getting beans", e);
			}
		}
*/
	}
}
