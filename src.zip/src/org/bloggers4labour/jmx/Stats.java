/**
 * Stats.java
 *
 * Created on Wed Jun 01 00:21:55 BST 2005
 */
package org.bloggers4labour.jmx;

import com.hiatus.USQL_Utils;
import com.hiatus.ULocale2;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import javax.management.*;
import org.apache.log4j.Logger;
import org.bloggers4labour.*;
import org.bloggers4labour.feed.FeedList;
import org.bloggers4labour.sql.DataSourceConnection;
import org.bloggers4labour.sql.QueryBuilder;
import org.bloggers4labour.tag.Link;

/**
 * Class Stats
 * B4L Stats
 * @author andrewre
 */
public class Stats implements StatsMBean
{
	private Date			m_StartupTime = new Date();

	private Date			m_LastUpdateTime;
	private long			m_BlogsCount = -1;
	private int			m_FeedCount;
	private int			m_SuccessfulFeedCount;		// (AGR) 7 October 2005
	private List			m_FailedFeedsList;		// " " "

	private int			m_SuccessfulCommentFeedCount;	// (AGR) 29 Nov 2005
	private int			m_FailedCommentFeedsCount;	// " " "
	private int			m_TimedOutCommentFeedsCount;	// " " "

	private List			m_FailedCommentFeedsList;	// " " "
	private int			m_RSSFeed_Count = -1;
	private StringBuffer		m_RSSFeed_Duration;
	private Date			m_RSSFeed_Completed;
	private int			m_ActiveSiteHandlerTasks;
	private Calendar		m_LastFeedCheckTime;		// (AGR) 23 July 2005

	private static Logger		s_Stats_Logger = Logger.getLogger("Main");
	private static TimeZone		s_TZ = ULocale2.getBestTimeZone( Locale.UK );

	/*******************************************************************************
	*******************************************************************************/
	public Stats()
	{
		DataSourceConnection	theConnectionObject = null;

		try
		{
			theConnectionObject = new DataSourceConnection();
			if (theConnectionObject.Connect())
			{
				Statement	theS = null;

				try
				{
					theS = theConnectionObject.createStatement();

					ResultSet	theRS = theS.executeQuery( QueryBuilder.getBlogsTotalQuery() );

					if (theRS.next())
					{
						m_BlogsCount = theRS.getLong(1);
					}
				}
				catch (Exception e)
				{
					s_Stats_Logger.error("creating statement", e);
				}
				finally
				{
					USQL_Utils.closeStatementCatch(theS);
				}
			}
			else
			{
				s_Stats_Logger.warn("Cannot connect!");
			}
		}
		catch (Exception err)
		{
			s_Stats_Logger.error("???", err);
		}
		finally
		{
			if ( theConnectionObject != null)
			{
				theConnectionObject.CloseDown();
				theConnectionObject = null;
			}
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public long getBlogsCount()
	{
		return m_BlogsCount;
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getFeedCount()
	{
		return m_FeedCount;
	}

	/*******************************************************************************
		(AGR) 7 October 2005
	*******************************************************************************/
	public int getSuccessfulFeedCount()
	{
		return m_SuccessfulFeedCount;
	}

	/*******************************************************************************
		(AGR) 7 October 2005
	*******************************************************************************/
	public List getFailedFeedsList()
	{
		return m_FailedFeedsList;
	}

	/*******************************************************************************
		(AGR) 7 October 2005
	*******************************************************************************/
	public void setFailedFeedsList( List inList)
	{
		m_FailedFeedsList = inList;
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	public void setFailedCommentFeedsList( List inList)
	{
		m_FailedCommentFeedsList = inList;
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	public List getFailedCommentFeedsList()
	{
		return m_FailedCommentFeedsList;
	}

	/*******************************************************************************
		(AGR) 30 Nov 2005
	*******************************************************************************/
	public void setFailedCommentFeedCount( int x)
	{
		m_FailedCommentFeedsCount = x;
	}

	/*******************************************************************************
		(AGR) 30 Nov 2005
	*******************************************************************************/
	public int getFailedCommentFeedCount()
	{
		return m_FailedCommentFeedsCount;
	}

	/*******************************************************************************
		(AGR) 30 Nov 2005
	*******************************************************************************/
	public void setTimedOutCommentFeedCount( int x)
	{
		m_TimedOutCommentFeedsCount = x;
	}

	/*******************************************************************************
		(AGR) 30 Nov 2005
	*******************************************************************************/
	public int getTimedOutCommentFeedCount()
	{
		return m_TimedOutCommentFeedsCount;
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getSuccessfulCommentFeedCount()
	{
		return m_SuccessfulCommentFeedCount;
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	public synchronized void setSuccessfulCommentFeedCount( int inCount)
	{
		m_SuccessfulCommentFeedCount = inCount;
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getBlogsUsedInLast24Hours()
	{
		return HeadlinesMgr.get24HourInstance().getBlogsCount();
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getRecentBlogsUsed()
	{
		return HeadlinesMgr.getRecentPostsInstance().getBlogsCount();
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getPostsMadeInLast24Hours()
	{
		return HeadlinesMgr.get24HourInstance().size();
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getRecentPostsMade()
	{
		return HeadlinesMgr.getRecentPostsInstance().size();
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getLinksFoundInLast24Hours()
	{
		return HeadlinesMgr.get24HourInstance().countLinks();
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getRecentCommentsLeft()
	{
		return HeadlinesMgr.getCommentsInstance().size();
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getRecentLinksFound()
	{
		return HeadlinesMgr.getRecentPostsInstance().countLinks();
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized void setFeedCount( int inCount)
	{
		m_FeedCount = inCount;
		m_LastUpdateTime = new Date();
	}

	/*******************************************************************************
		(AGR) 7 October 2005
	*******************************************************************************/
	public synchronized void setSuccessfulFeedCount( int inCount)
	{
		m_SuccessfulFeedCount = inCount;
		m_LastUpdateTime = new Date();
	}

	/*******************************************************************************
	*******************************************************************************/
	public Date getLastUpdateTime()
	{
		return m_LastUpdateTime;
	}

	/*******************************************************************************
	*******************************************************************************/
	public void setLastUpdateTime( Date x)
	{
		m_LastUpdateTime = x;
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized void setRSSFeedDetails( int inCount, long inDoneMS, StringBuffer inTimeStr)
	{
		m_RSSFeed_Count = inCount;
		m_RSSFeed_Duration = inTimeStr;
		m_RSSFeed_Completed = new Date(inDoneMS);
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getRSSFeedItemCount()
	{
		return m_RSSFeed_Count;
	}

	/*******************************************************************************
	*******************************************************************************/
	public Date getRSSFeedCompletionTime()
	{
		return m_RSSFeed_Completed;
	}

	/*******************************************************************************
	*******************************************************************************/
	public StringBuffer getRSSFeedCompletionInterval()
	{
		return m_RSSFeed_Duration;
	}

	/*******************************************************************************
	*******************************************************************************/
	public Date getStartupTime()
	{
		return m_StartupTime;
	}

	/*******************************************************************************
	*******************************************************************************/
	public void setActiveSiteHandlerTasks( int x)
	{
		m_ActiveSiteHandlerTasks = x;
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getActiveSiteHandlerTasks()
	{
		return m_ActiveSiteHandlerTasks;
	}

	/*******************************************************************************
	*******************************************************************************/
	public List<Site> getCurrentSites()
	{
		return FeedList.getInstance().getSites();
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getReferencedItemsCount()
	{
		return FeedList.getInstance().countReferencedItems();
	}

	/*******************************************************************************
	*******************************************************************************/
	public String getOPMLOutputStr()
	{
		return FeedList.getInstance().getOPMLOutputStr();
	}

	/*******************************************************************************
		(AGR) 23 July 2005
	*******************************************************************************/
	public Calendar getLastFeedCheckTime()
	{
		return m_LastFeedCheckTime;
	}

	/*******************************************************************************
		(AGR) 23 July 2005
	*******************************************************************************/
	public void setLastFeedCheckTimeNow()
	{
		m_LastFeedCheckTime = Calendar.getInstance( s_TZ, Locale.UK);
	}

	/*******************************************************************************
		(AGR) 23 July 2005
	*******************************************************************************/
	public void setLastFeedCheckTime( Calendar x)
	{
		m_LastFeedCheckTime = x;
	}

	/*******************************************************************************
		(AGR) 6 June 2005. My first Operation
	*******************************************************************************/
	public Site getSite( long inSiteRecno)
	{
		return FeedList.getInstance().lookup(inSiteRecno);
	}

	/*******************************************************************************
		(AGR) 6 June 2005. My 2nd Operation
	*******************************************************************************/
	public String getAgeDifferenceString( long inAgeDiffMSecs)
	{
		return FeedUtils.getAgeDifferenceString(inAgeDiffMSecs);
	}

	/*******************************************************************************
		(AGR) 6 June 2005. My 3rd Operation
	*******************************************************************************/
	public String stripHTML( String inStr)
	{
		return FeedUtils.stripHTML(inStr);
	}
}
