/*
 * Handler.java
 *
 * Created on July 10, 2005, 9:26 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour.headlines;

import org.bloggers4labour.Headlines;

/**
 *
 * @author andrewre
 */
public interface Handler
{
	
}
