/*
 * AddHandler.java
 *
 * Created on June 25, 2005, 9:39 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour.headlines;

import de.nava.informa.core.ItemIF;
import org.bloggers4labour.Headlines;

/**
 *
 * @author andrewre
 */
public interface AddHandler extends Handler
{
	public void onAdd( HeadlinesIF inHeads, final ItemIF inItem);
}
