/*
 * Superscript.java
 *
 * Created on May 30, 2005, 12:08 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour.tag;

/********************************************************************
	(AGR) 11 May 2005
********************************************************************/
public class Superscript extends Tag
{
	/********************************************************************
	********************************************************************/
	public Superscript( int inStartPos, int inEndPos, String inName)
	{
		super( inStartPos, inEndPos, inName);
	}
}
