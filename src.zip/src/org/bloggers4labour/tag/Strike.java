/*
 * Strike.java
 *
 * Created on August 4, 2005, 9:40 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour.tag;

/********************************************************************
	(AGR) 4 August 2005
********************************************************************/
public class Strike extends Tag
{
	/********************************************************************
	********************************************************************/
	public Strike( int inStartPos, int inEndPos, String inName)
	{
		super( inStartPos, inEndPos, inName);
	}
}
