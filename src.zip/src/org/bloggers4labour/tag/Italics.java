/*
 * Italics.java
 *
 * Created on January 16, 2006, 11:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.tag;

/********************************************************************
	@author andrewre
********************************************************************/
public class Italics extends Tag
{
	/********************************************************************
	********************************************************************/
	public Italics( int inStartPos, int inEndPos, String inName)
	{
		super( inStartPos, inEndPos, inName);
	}
}