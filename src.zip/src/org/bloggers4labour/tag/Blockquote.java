/*
 * Blockquote.java
 *
 * Created on 28 August 2006, 23:25
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.tag;

/**
 *
 * @author andrewre
 */
public class Blockquote extends Tag
{
	/********************************************************************
	********************************************************************/
	public Blockquote( int inStartPos, int inEndPos, String inName)
	{
		super( inStartPos, inEndPos, inName);
	}
}