/*
 * FormatOption.java
 *
 * Created on 27 May 2005, 16:40
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour;

/**
 *
 * @author regana
 */
public enum FormatOption
{
	BASIC, ALLOW_IMAGES, ALLOW_BREAKS;
}
