/*
 * ItemContext.java
 *
 * Created on 23 February 2006, 22:47
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour;

/**
 *
 * @author andrewre
 */
public enum ItemContext
{
	SNAPSHOT, UPDATE
}
