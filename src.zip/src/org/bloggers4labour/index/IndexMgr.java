/*
 * IndexMgr.java
 *
 * Created on June 20, 2005, 8:17 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour.index;

import de.nava.informa.core.ChannelIF;
import de.nava.informa.core.ItemIF;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.lucene.analysis.standard.*;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.queryParser.*;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.bloggers4labour.FeedUtils;
import org.bloggers4labour.Headlines;
import org.bloggers4labour.HeadlinesMgr;
import org.bloggers4labour.Site;
import org.bloggers4labour.feed.FeedList;
import org.bloggers4labour.headlines.*;

/**
 *
 * @author andrewre
 */
public class IndexMgr
{
	private int			m_DocCount;

	private static Logger		s_Idx_Logger = Logger.getLogger("Main");
	private static File		s_LuceneIndexDir = new File("/Users/andrewre/Development/java/Bloggers4Labour/lucene_index");
	private static int		s_Dirtiness = 0;
	
	/*******************************************************************************
		(AGR) 22 June 2005. Should really sync, in case someone calls
		setDirectory() again, but that's the last thing we want to do!
	*******************************************************************************/
	private IndexMgr()
	{
		IndexWriter	iw = null;

		try
		{
			Headlines	h = HeadlinesMgr.getIndexablePostsInstance();

			s_Idx_Logger.info("IndexMgr: storing in \"" + s_LuceneIndexDir + "\"");
			iw = getIndexWriter(true);

			////////////////////////////////////////////////////////  (AGR) 25 June 2005

			if ( h != null)
			{
				AddHandler	ah = new NewHeadlineHandler();
				RemoveHandler	rh = new ExpiredHeadlineHandler();

				s_Idx_Logger.info("IndexMgr: registering: " + ah + " with " + h);
				h.addHandler(ah);
				s_Idx_Logger.info("IndexMgr: registering: " + rh + " with " + h);
				h.addHandler(rh);
			}
			else
			{
				s_Idx_Logger.error("IndexMgr: no Headlines object to attach to!");
			}
		}
		catch (Exception e)
		{
			s_Idx_Logger.error("Clearing Index failed", e);
		}
		finally
		{
			closeIndexWriter(iw);
		}
	}

	/*******************************************************************************
		(AGR) 22 June 2005
	*******************************************************************************/
	public synchronized static void setDirectory( String inDir)
	{
		s_LuceneIndexDir = new File(inDir);
	}

	/*******************************************************************************
	*******************************************************************************/
	public static IndexMgr getInstance()
	{
		return LazyHolder.s_Inst;
	}

	/*******************************************************************************
	*******************************************************************************/
	private static class LazyHolder
	{
		private static IndexMgr	s_Inst = new IndexMgr();
	}

	/*******************************************************************************
	*******************************************************************************/
	private synchronized boolean insert( HeadlinesIF inHeads, Document inDoc, String inTitle)
	{
/*		if (IndexReader.indexExists(s_LuceneIndexDir))
		{
			IndexReader	theReader = null;

			try
			{
				theReader = IndexReader.open(s_LuceneIndexDir);

				m_DocCount = theReader.numDocs();

				String	ours = inDoc.getField("item_id").stringValue();

				for ( int i = 0; i < m_DocCount; i++)
				{
					String	theirs = theReader.document(i).getField("item_id").stringValue();

					if (theirs.equals(ours))
					{
						System.out.println("!!!! index #" + i + " !!!");
						return false;
					}
				}
			}
			catch (IOException e)
			{
				s_Idx_Logger.error("", e);
			}
			finally
			{
				closeIndexReader(theReader);
			}
		}
*/
		////////////////////////////////////////////////////////////////

		IndexWriter	theWriter = null;

		try
		{
			theWriter = getIndexWriter(false);

			int	x0 = theWriter.docCount();
			theWriter.addDocument(inDoc);
			m_DocCount = theWriter.docCount();

			// s_Idx_Logger.info("IDX: added  " + (m_DocCount-x0) + " doc ('" + inTitle + "'), total is now " + m_DocCount); // + ", " + inHeads.size() + " in headlines");

			s_Dirtiness++;

			return true;
		}
		catch (Exception err)
		{
			s_Idx_Logger.error( "insert()", err);
		}
		finally
		{
			closeIndexWriter(theWriter);
		}

		return false;
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized void optimise()
	{
		if ( s_Dirtiness >= 5)
		{
			IndexWriter	theWriter = null;

			try
			{
				theWriter = getIndexWriter(false);
				theWriter.optimize();

				s_Dirtiness = 0;
				m_DocCount = theWriter.docCount();
				s_Idx_Logger.info("IDX: optimised ->  " + m_DocCount + " docs.");
			}
			catch (Exception err)
			{
				s_Idx_Logger.error( "optimise()", err);
			}
			finally
			{
				closeIndexWriter(theWriter);
			}
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized int remove( HeadlinesIF inHeads, Term inTerm)
	{
		if (IndexReader.indexExists(s_LuceneIndexDir))
		{
			IndexReader	theReader = null;

			try
			{
				theReader = IndexReader.open(s_LuceneIndexDir);

				int	x = theReader.delete(inTerm);

				m_DocCount = theReader.numDocs();
				s_Dirtiness++;

/*				s_Idx_Logger.info("IDX: removed " + x + " docs, total is now " + m_DocCount + ", " + inHeads.size() + " in headlines"); // ", term was " + inTerm);

				List	ourList = this.getItemIDs();
				List	theirList = inHeads.getItemIDs();
				if (!ourList.equals(theirList))
				{
					s_Idx_Logger.info("IDX:   ours = " + ourList);
					s_Idx_Logger.info("IDX: theirs = " + theirList);
				}
*/
				return x;
			}
			catch (IOException e)
			{
				s_Idx_Logger.error("remove", e);
			}
			finally
			{
				closeIndexReader(theReader);
			}
		}

		return 0;
	}

	/*******************************************************************************
	*******************************************************************************
	public synchronized List<Long> getItemIDs()
	{
		List<Long>	ll = new ArrayList<Long>();

		if (IndexReader.indexExists(s_LuceneIndexDir))
		{
			IndexReader	theReader = null;

			try
			{
				theReader = IndexReader.open(s_LuceneIndexDir);

				int	dc = theReader.numDocs();

				for ( int i = 0; i < dc; i++)
				{
					ll.add( Long.valueOf( theReader.document(i).getField("item_id").stringValue() ) );
				}
			}
			catch (IOException e)
			{
				s_Idx_Logger.error("", e);
			}
			finally
			{
				closeIndexReader(theReader);
			}
		}

		java.util.Collections.sort(ll);
		return ll;
	}/

	/*******************************************************************************
	*******************************************************************************/
	private IndexWriter getIndexWriter( boolean inClearContents) throws IOException
	{
		IndexWriter	theWriter;

		if ( !inClearContents && IndexReader.indexExists(s_LuceneIndexDir))
		{
			theWriter = new IndexWriter( s_LuceneIndexDir, new StandardAnalyzer(), false);

			// m_Logger.info("existing writer = " + theWriter);
		}
		else
		{
			theWriter = new IndexWriter( s_LuceneIndexDir, new StandardAnalyzer(), true);

			s_Idx_Logger.info("new writer = " + theWriter);
		}

		return theWriter;
	}

	/*******************************************************************************
	*******************************************************************************/
	private void closeIndexReader( IndexReader inReader)
	{
		if ( inReader != null)
		{
			try
			{
				inReader.close();
			}
			catch (IOException err)
			{
				s_Idx_Logger.error( "closeIndexReader()", err);
			}
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	private void closeIndexSearcher( IndexSearcher inSearcher)
	{
		if ( inSearcher != null)
		{
			try
			{
				inSearcher.close();
			}
			catch (IOException err)
			{
				s_Idx_Logger.error( "closeIndexSearcher()", err);
			}
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	private void closeIndexWriter( IndexWriter inWriter)
	{
		if ( inWriter != null)
		{
			try
			{
				inWriter.close();
			}
			catch (IOException err)
			{
				s_Idx_Logger.error( "closeIndexWriter()", err);
			}
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized int numDocs()
	{
		return m_DocCount;
	}

	/*******************************************************************************
	*******************************************************************************/
	public List<SearchMatch> runQuery( final String inQueryStr)
	{
		if (IndexReader.indexExists(s_LuceneIndexDir))
		{
			IndexReader	theReader = null;
			IndexSearcher	theSearcher = null;

			try
			{
				theReader = IndexReader.open(s_LuceneIndexDir);
				theSearcher = new IndexSearcher(theReader);

				// int	theNumDocs = theReader.numDocs();

				QueryParser	theParser = new QueryParser( "desc", new StandardAnalyzer());

				return _runQuery( theReader, theSearcher, theParser.parse(inQueryStr));
			}
			catch (IOException e)
			{
				s_Idx_Logger.error("", e);
			}
			catch (ParseException e)
			{
				s_Idx_Logger.error("", e);
			}
			finally
			{
				closeIndexSearcher(theSearcher);
				closeIndexReader(theReader);
			}
		}

		return null;
	}

	/*******************************************************************************
	*******************************************************************************/
	public List<SearchMatch> runQuery( final Query inQuery)
	{
		if (IndexReader.indexExists(s_LuceneIndexDir))
		{
			IndexReader	theReader = null;
			IndexSearcher	theSearcher = null;

			try
			{
				theReader = IndexReader.open(s_LuceneIndexDir);
				theSearcher = new IndexSearcher(theReader);

				return _runQuery( theReader, theSearcher, inQuery);
			}
			catch (IOException e)
			{
				s_Idx_Logger.error("", e);
			}
			finally
			{
				closeIndexSearcher(theSearcher);
				closeIndexReader(theReader);
			}
		}

		return null;
	}

	/*******************************************************************************
	*******************************************************************************/
	private List<SearchMatch> _runQuery( final IndexReader inReader, final IndexSearcher inSearcher, Query inQuery) throws IOException
	{
		Hits	theHits = inSearcher.search(inQuery);

		if ( theHits != null)
		{
			int			theLength = theHits.length();
			List<SearchMatch>	theList = new ArrayList<SearchMatch>(theLength);

			for ( int i = 0; i < theLength; i++)
			{
				if (!inReader.isDeleted(i))
				{
					theList.add( new SearchMatch( theHits.score(i), theHits.doc(i)) );
				}
			}

			return theList;
		}

		return null;
	}

	/*******************************************************************************
		(AGR) 25 June 2005
	*******************************************************************************/
	private class NewHeadlineHandler implements AddHandler
	{
		/*******************************************************************************
		*******************************************************************************/
		public void onAdd( HeadlinesIF inHeads, final ItemIF inItem)
		{
			ChannelIF	theChannel = inItem.getChannel();
/*			Site		thisChannelsSite = FeedList.getInstance().lookupChannel(theChannel);
			boolean		itemIsAPost = ( thisChannelsSite.getChannel() == theChannel);

			if (!itemIsAPost)
			{
				return;		// (AGR) 1 Dec 2005. No, we don't index comments at this time...
			}
*/
			////////////////////////////////////////////////////////

			Document	theDocument = new Document();
			String		theDescr = FeedUtils.stripHTML( inItem.getDescription() );
			String		theTitle = FeedUtils.adjustTitle(inItem);
			long		itemTimeMsecs = FeedUtils.getItemDate(inItem).getTime();

			theDocument.add( Field.Text( "desc", theDescr) );
			theDocument.add( Field.Text( "title", theTitle) );

			// Need to store this so we can use it as a key for deleting this entry later!

			theDocument.add( Field.Keyword( "item_id", Long.toString( inItem.getId() ) ) );
			theDocument.add( Field.UnIndexed( "item_time_ms", Long.toString(itemTimeMsecs)) );

			URL	theLink = inItem.getLink();

			if ( theLink != null)	// (AGR) 13 Jan 2006. Groan...
			{
				theDocument.add( Field.UnIndexed( "item_link", theLink.toString() ) );
			}

			try {
				theDocument.add( Field.UnIndexed( "channel_site", theChannel.getSite().toString() ) );
			} catch (Exception e) {		// (AGR) 26 July 2005
				;
			}

			// System.out.println("Adding Doc '" + theTitle + "' to " + this);

			insert( inHeads, theDocument, theTitle);
		}
	}

	/*******************************************************************************
		(AGR) 25 June 2005
	*******************************************************************************/
	private class ExpiredHeadlineHandler implements RemoveHandler
	{
		/*******************************************************************************
		*******************************************************************************/
		public void onRemove( HeadlinesIF inHeads, final ItemIF inItem)
		{
			remove( inHeads, new Term( "item_id", Long.toString( inItem.getId() ) ) );
		}
	}
}
