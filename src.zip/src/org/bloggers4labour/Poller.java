/*
 * Poller.java
 *
 * Created on 12 March 2005, 01:11
 */

package org.bloggers4labour;

import com.hiatus.UDates;
import de.nava.informa.parsers.*;
import de.nava.informa.core.*;
import de.nava.informa.utils.poller.*;
import de.nava.informa.impl.basic.ChannelBuilder;
import de.nava.informa.impl.basic.Item;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import org.apache.log4j.Logger;
import org.bloggers4labour.cats.CategoriesTable;
import org.bloggers4labour.feed.FeedList;
import static org.bloggers4labour.Constants.*;

/**
 *
 * @author andrewre
 */
public class Poller
{
	private PollerObserverIF				m_Observer;

	private static Logger					s_Poll_Logger = Logger.getLogger("Main");
	private static de.nava.informa.utils.poller.Poller	s_InformaPoller;

	private static Item[]					s_EmptyItemsArray = new Item[0];

	private final static int				MAX_POSTS_PER_BLOG	= 40;	// (AGR) 3 April 2005. Raised from 10 because of MadMusingsOfMe !
	private final static int				MAX_COMMENTS_PER_POST	= 50;	// (AGR) 29 Nov 2005

	private enum AddResult	// (AGR) 27 May 2005
	{
		SUCCEEDED, FAILED_NO_DATE, FAILED_GENERAL, FAILED_BAD_DATE;
	}

	/*******************************************************************************
		(AGR) 27 May 2005
		Only want one of these - it contains a Thread Pool
	*******************************************************************************/
	static
	{
		s_InformaPoller = new de.nava.informa.utils.poller.Poller();
		s_InformaPoller.setPeriod( 2 * ONE_MINUTE_MSECS );	// default is 1 HOUR!

		System.out.println("Informa Poller: created " + s_InformaPoller);
	}

	/*******************************************************************************
		(AGR) 10 June 2005
	*******************************************************************************/
	public static Poller getInstance()
	{
		return LazyHolder.s_Poller;
	}
	
	/*******************************************************************************
		(AGR) 10 June 2005. See:
		    <http://www-106.ibm.com/developerworks/java/library/j-jtp03304/>
	*******************************************************************************/
	private static class LazyHolder
	{
		private static Poller	s_Poller = new Poller();
	}

	/*******************************************************************************
	*******************************************************************************/
	private Poller()
	{
		_startPolling();
	}

	/*******************************************************************************
	*******************************************************************************/
	private void _startPolling()
	{
		m_Observer = new MyObserver();

		s_InformaPoller.addObserver(m_Observer);

		// s_Poll_Logger.info("Poller: add Observer: " + m_Observer);
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized void startPolling()
	{
		if ( m_Observer == null)
		{
			_startPolling();
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized void cancelPolling()
	{
		if ( m_Observer != null)
		{
			s_Poll_Logger.info("Poller: removing Observer: " + m_Observer + " and stopping");

			s_InformaPoller.removeObserver(m_Observer);

			m_Observer = null;
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	private void _processChannelItems( ChannelIF inChannel, long inCurrentTimeMSecs)
	{
		Item[]	theItemsArray = _getChannelItemsArray(inChannel);

		if ( theItemsArray.length > 0)
		{
			int[]			hCountArray = new int[ HeadlinesMgr.getHeadlinesCount() ];	// (AGR) 22 May 2005
			CategoriesTable		theCatsTable = CategoriesTable.getInstance();

			for ( int i = 0; i < theItemsArray.length; i++)
			{
				Date		itemDate = FeedUtils.getItemDate( theItemsArray[i] );
				AgeResult	theAgeResult = _getItemAgeMsecs( theItemsArray[i], itemDate, inCurrentTimeMSecs);

				if (!theAgeResult.isAllowable())	// (AGR) 14 Jan 2006
				{
					continue;
				}

				//////////////////////////////////////////////////////////////////  (AGR) 19 May 2005

				if (( theCatsTable != null) && ( itemDate != null) && theAgeResult.getAgeMSecs() < CategoriesTable.MAX_CATEGORY_AGE_MSECS)
				{
					theCatsTable.addCategories( theItemsArray[i] );
				}

				//////////////////////////////////////////////////////////////////

				int	hIndex = 0;

				for ( Headlines	h : HeadlinesMgr.getHeadlinesList())
				{
					if (!h.allowsPosts())	// (AGR) 29 Nov 2005
					{
						continue;
					}

					///////////////////////////////////////////////////////

					if ( hCountArray[hIndex] > MAX_POSTS_PER_BLOG)
					{
						continue;
					}

					///////////////////////////////////////////////////////

					AddResult	theResult;

					if ( itemDate == null)
					{
						theResult = AddResult.FAILED_NO_DATE;
					}
					else	theResult = _processItem( h, theItemsArray[i], theAgeResult.getAgeMSecs());

					///////////////////////////////////////////////////////

					if ( theResult == AddResult.SUCCEEDED)
					{
						hCountArray[hIndex]++;
					}

					hIndex++;
				}
			}
		}
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	private void _processCommentChannelItems( ChannelIF inChannel, long inCurrentTimeMSecs)
	{
		Item[]		theItemsArray = _getChannelItemsArray(inChannel);
		int[]		hCommentsCountArray = new int[ HeadlinesMgr.getHeadlinesCount() ];
		AddResult	theResult;

		for ( int i = 0; i < theItemsArray.length; i++)
		{
			Date		itemDate = FeedUtils.getItemDate( theItemsArray[i] );
			AgeResult	theAgeResult = _getItemAgeMsecs( theItemsArray[i], itemDate, inCurrentTimeMSecs);

			if (!theAgeResult.isAllowable())	// (AGR) 14 Jan 2006
			{
				continue;
			}

			//////////////////////////////////////////////////////////////////

			int	hIndex = 0;

			for ( Headlines	h : HeadlinesMgr.getHeadlinesList())
			{
				if (!h.allowsComments())	// (AGR) 29 Nov 2005
				{
					continue;
				}

				///////////////////////////////////////////////////////

				if ( hCommentsCountArray[hIndex] > MAX_COMMENTS_PER_POST)
				{
					continue;
				}

				///////////////////////////////////////////////////////

				if ( itemDate == null)
				{
					theResult = AddResult.FAILED_NO_DATE;
				}
				else	theResult = _processItem( h, theItemsArray[i], theAgeResult.getAgeMSecs());

				///////////////////////////////////////////////////////

				if ( theResult == AddResult.SUCCEEDED)
				{
					hCommentsCountArray[hIndex]++;
				}

				hIndex++;
			}
		}
	}

	/*******************************************************************************
		(AGR) 12 Dec 2005
		A result of seeing yet more ConcurrentModificationExceptions
	*******************************************************************************/
	private synchronized Item[] _getChannelItemsArray( final ChannelIF inChannel)
	{
		Collection	c = inChannel.getItems();

		return ( c != null) ? (Item[]) c.toArray(s_EmptyItemsArray) : s_EmptyItemsArray;
	}

	/*******************************************************************************
	*******************************************************************************/
	private AgeResult _getItemAgeMsecs( ItemIF inItem, Date inItemDate, long inCurrentTimeMSecs)
	{
		if ( inItemDate == null)
		{
			return new AgeResult(0);	// !!! This value should never, in practice, be used.
		}

		////////////////////////////////////////////////////////

		long	itemAgeMSecs = inCurrentTimeMSecs - inItemDate.getTime();

// System.out.println( FeedUtils.getDisplayTitle(inItem) + "\t\t" + inItemDate);

		if ( itemAgeMSecs >= 0)
		{
			return new AgeResult(itemAgeMSecs);
		}

// System.out.println( FeedUtils.getDisplayTitle(inItem) + "\t\t" + itemAgeMSecs);

		////////////////////////////////////////////////////////

		Date	d = FeedUtils.adjustFutureItemDate( inItem, inItemDate, itemAgeMSecs);

// System.out.println( "===>\t\t" + d);

		return new AgeResult( inCurrentTimeMSecs - d.getTime());
	}

	/*******************************************************************************
	*******************************************************************************/
	private AddResult _processItem( Headlines ioHeadlines, ItemIF inItem, long inAgeMSecs)
	{
		if (ioHeadlines.isItemAgeOK(inAgeMSecs))
		{
			if (ioHeadlines.put(inItem))
			{
				return AddResult.SUCCEEDED;
			}

			return AddResult.FAILED_GENERAL;
		}

		return AddResult.FAILED_BAD_DATE;
	}

	/*******************************************************************************
	*******************************************************************************/
	public boolean registerChannel( ChannelIF inChannel, long inCurrentTimeMSecs)
	{
		// s_Poll_Logger.info("Poller: registering " + inChannel + " @ " + inCurrentTimeMSecs);

		s_InformaPoller.registerChannel( inChannel, /* Note Channel polling every 5 minutes! */ 5 * ONE_MINUTE_MSECS);

		_processChannelItems( inChannel, inCurrentTimeMSecs);

		return true;
	}

	/*******************************************************************************
		(AGR) 29 Nov 2005
	*******************************************************************************/
	public boolean registerCommentsChannel( ChannelIF inChannel, long inCurrentTimeMSecs)
	{
		s_InformaPoller.registerChannel( inChannel, /* Note Channel polling every 5 minutes! */ 5 * ONE_MINUTE_MSECS);

		_processCommentChannelItems( inChannel, inCurrentTimeMSecs);

		return true;
	}

	/*******************************************************************************
	*******************************************************************************/
	public boolean unregisterChannel( ChannelIF inChannel)
	{
		s_Poll_Logger.info("Poller: UN-registering " + inChannel);

		s_InformaPoller.unregisterChannel(inChannel);

		return true;
	}

	/*******************************************************************************
	*******************************************************************************/
	private class MyObserver implements PollerObserverIF
	{
		/*******************************************************************************
		*******************************************************************************/
		public void pollStarted( ChannelIF inChannel)
		{
			// s_Poll_Logger.info("... Polling started for " + inChannel);
		}

		/*******************************************************************************
		*******************************************************************************/
		public void pollFinished( ChannelIF inChannel)
		{
			;
		}

		/*******************************************************************************
		*******************************************************************************/
		public void channelChanged( ChannelIF inChannel)
		{
			// s_Poll_Logger.info("... " + inChannel + " CHANGED!");
		}

		/*******************************************************************************
		*******************************************************************************/
		public void channelErrored( ChannelIF inChannel, Exception inE)
		{
			s_Poll_Logger.warn("... ERROR for " + inChannel + "! ", inE);
		}

		/*******************************************************************************
		*******************************************************************************/
		public void itemFound( ItemIF inItem, ChannelIF ioChannel)
		{
			CategoriesTable		theCatsTable = CategoriesTable.getInstance();
			String			titleStr = FeedUtils.adjustTitle(inItem);
			String			channelStr = FeedUtils.channelToString(ioChannel);
			Date			itemDate = FeedUtils.getItemDate(inItem);
			AgeResult		theAgeResult = _getItemAgeMsecs( inItem, itemDate, System.currentTimeMillis());

			if (!theAgeResult.isAllowable())	// (AGR) 14 Jan 2006
			{
				return;
			}

			//////////////////////////////////////////////////////////////////

			// s_Poll_Logger.info("... found \"" + titleStr + "\" for \"" + channelStr + "\" - add it");

			ioChannel.addItem(inItem);

			//////////////////////////////////////////////////////////////////  (AGR) 19 May 2005

			if (( theCatsTable != null) && ( itemDate != null) && theAgeResult.getAgeMSecs() < CategoriesTable.MAX_CATEGORY_AGE_MSECS)
			{
				theCatsTable.addCategories(inItem);
			}

			//////////////////////////////////////////////////////////////////  (AGR) 30 Nov 2005. A comment or a post???

			Site	thisChannelsSite = FeedList.getInstance().lookupChannel(ioChannel);

			if ( thisChannelsSite == null)
			{
				s_Poll_Logger.error("... CANNOT add \"" + titleStr + "\" for \"" + channelStr + "\" as Site lookup returned NULL");
				return;
			}

			boolean	itemIsAPost = ( thisChannelsSite.getChannel() == ioChannel);

			//////////////////////////////////////////////////////////////////

			for ( Headlines	h : HeadlinesMgr.getHeadlinesList())
			{
				if (( itemIsAPost && !h.allowsPosts()) ||
				   ( !itemIsAPost && !h.allowsComments()))
				{
					continue;
				}

				//////////////////////////////////////////////////////////////////

				AddResult	itemResult;

				if ( itemDate == null)
				{
					itemResult = AddResult.FAILED_NO_DATE;
				}
				else	itemResult = _processItem( h, inItem, theAgeResult.getAgeMSecs());

				//////////////////////////////////////////////////////////////////

				if ( itemResult == AddResult.SUCCEEDED)
				{
//					s_Poll_Logger.info("... found \"" + titleStr + "\" for \"" + channelStr + "\" - ADDED OK to " + h);
				}
				else if ( itemResult == AddResult.FAILED_NO_DATE)
				{
					s_Poll_Logger.warn("... found \"" + titleStr + "\" for \"" + channelStr + "\" - FAILED - Date is NULL, for " + h);
				}
				else if ( itemResult == AddResult.FAILED_BAD_DATE)
				{
					// s_Poll_Logger.warn("... found \"" + titleStr + "\" for \"" + channelStr + "\" - FAILED - Date out of range! " + m_LastInfoMsg);
				}
				else if ( itemResult == AddResult.FAILED_GENERAL)
				{
					s_Poll_Logger.warn("... found \"" + titleStr + "\" for \"" + channelStr + "\" - FAILED, somehow, for " + h);
				}
			}
		}
	}

	/*******************************************************************************
		(AGR) 14 Jan 2006

		Why? Because some item ages are no longer permissible (items a week or
		more in the future)
	*******************************************************************************/
	private class AgeResult
	{
		private long		m_AgeMSecs;
		private boolean		m_Allowable;

		/*******************************************************************************
		*******************************************************************************/
		public AgeResult( long inMSecs)
		{
			m_AgeMSecs = inMSecs;
			m_Allowable = FeedUtils.isAcceptableFutureDate(inMSecs);

/*			if (!m_Allowable)
			{
				s_Poll_Logger.info("Skipping future post: " + FeedUtils.getAgeDifferenceString(inMSecs));
			}
*/		}

		/*******************************************************************************
		*******************************************************************************/
		public AgeResult( long inMSecs, boolean isAllowable)
		{
			m_AgeMSecs = inMSecs;
			m_Allowable = isAllowable;
		}

		/*******************************************************************************
		*******************************************************************************/
		public long getAgeMSecs()
		{
			return m_AgeMSecs;
		}

		/*******************************************************************************
		*******************************************************************************/
		public boolean isAllowable()
		{
			return m_Allowable;
		}
	}
}
