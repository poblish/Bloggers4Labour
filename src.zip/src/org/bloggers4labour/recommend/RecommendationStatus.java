/*
 * RecommendationStatus.java
 *
 * Created on 20 June 2006, 00:45
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.recommend;

/**
 *
 * @author andrewre
 */
public enum RecommendationStatus
{
	OK, DUPLICATE, BAD_INPUTS, ERROR, UNKNOWN_SITE
}
