/*
 * ItemType.java
 *
 * Created on December 1, 2005, 5:49 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour;

/**
 *
 * @author andrewre
 */
public enum ItemType
{
	UNKNOWN, POST, COMMENT, FOAF
}
