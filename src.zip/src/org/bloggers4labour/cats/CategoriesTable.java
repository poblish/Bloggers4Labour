/*
 * CategoriesTable.java
 *
 * Created on May 19, 2005, 9:48 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bloggers4labour.cats;

import com.hiatus.UDates;
import de.nava.informa.impl.basic.Item;
import de.nava.informa.core.*;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.Timer;
import java.util.TreeMap;
import java.util.TreeSet;
import org.apache.log4j.Logger;
import org.bloggers4labour.feed.FeedList;
import org.bloggers4labour.FeedUtils;
import org.bloggers4labour.ItemCleanerTask;
import org.bloggers4labour.options.Options;
import org.bloggers4labour.options.TaskOptionsBeanIF;
import static org.bloggers4labour.Constants.*;

/**
 *
 * @author andrewre
 */
public class CategoriesTable
{
	private Map<String,List<ItemIF> >	m_Map;
	private int				m_EntriesCount;
	private int				m_MinEntryCount;
	private int				m_MaxEntryCount;

	private Timer				m_ExpiryTimer;
	private ItemCleanerTask			m_ExpiryTask;

	private static Logger			s_Headlines_Logger = Logger.getLogger("Main");

	public final static long		MAX_CATEGORY_AGE_MSECS = ONE_WEEK_MSECS;    // (AGR) 19 May 2005

	/*******************************************************************************
	*******************************************************************************/
	private CategoriesTable()
	{
		m_Map = new TreeMap<String,List<ItemIF> >( new CategoryNameSorter() );

		FeedList.getInstance().addObserver( new CountEvent() );    // (AGR) 22 June 2005

		reconnect();
	}
	
	/*******************************************************************************
	*******************************************************************************/
	public static CategoriesTable getInstance()
	{
		return LazyHolder.s_Table;
	}
	
	/*******************************************************************************
		(AGR) 5 June 2005. See:
		    <http://www-106.ibm.com/developerworks/java/library/j-jtp03304/>
	*******************************************************************************/
	private static class LazyHolder
	{
		private static CategoriesTable	s_Table = Options.getOptions().getIsStoringCategories() ? new CategoriesTable() : null;
	}

	/*******************************************************************************
		(AGR) 5 June 2005. The first ref to 's_Table' will load the class if,
		for some reason, .clear() is called before getInstance(). It can only
		be NULL if Category storage is turned off in the Options. Should never
		set 's_Table' too NULL.
	*******************************************************************************/
	public static void clear()
	{
		if ( LazyHolder.s_Table != null)
		{
			LazyHolder.s_Table.clearTable();
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public void reconnect()
	{
		if ( m_ExpiryTimer == null)
		{
			m_ExpiryTimer = new Timer();
		}

		if ( m_ExpiryTask == null)
		{
			m_ExpiryTask = new ExpiryTask( MAX_CATEGORY_AGE_MSECS );
		}

		////////////////////////////////////////////////////////////////

		TaskOptionsBeanIF	theOptionsBean = Options.getOptions().getExpiryTaskOptions();

		m_ExpiryTimer.scheduleAtFixedRate( m_ExpiryTask,
						   theOptionsBean.getDelayMsecs(),
						   theOptionsBean.getPeriodMsecs());
	}

	/*******************************************************************************
	*******************************************************************************/
	public void addCategories( ItemIF inItem)
	{
		addCategories( inItem, inItem.getCategories());
	}

	/*******************************************************************************
		(AGR) 5 June 2005 - made synchronized.
	*******************************************************************************/
	public synchronized void addCategories( ItemIF inItem, Collection inCats)
	{
		ChannelIF	ch = inItem.getChannel();

		for ( Object obj : inCats)
		{
			String	theKey = ((CategoryIF) obj).getTitle().trim();

			if (theKey.equalsIgnoreCase("Uncategorized"))	// (AGR) 28 May 2005
			{
				continue;
			}

			////////////////////////////////////////////////////////

			List<ItemIF>	theList = getCategoryEntries(theKey);

			if ( theList == null)
			{
				theList = new ArrayList<ItemIF>();
				m_Map.put( theKey, theList);

				// s_Headlines_Logger.info("  => Add category \"" + theKey + "\" from \"" + ch.getTitle() + "\"");
			}

			// (AGR) 25 May 2005. We need to supply a Channel, because otherwise the Site
			// object lookups will fail, and this'll cause us to see "???" in the posts on
			// the Tags page, not the actual site name or icon.

			theList.add( FeedUtils.cloneItem( ch, inItem, true) );
//			theList.add( Options.CATEGORY_STORE_ITEM_CLONE ? FeedUtils.cloneItem( null, inItem, true) : inItem);
			m_EntriesCount++;
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public Map getData()
	{
		return m_Map;
	}

	/*******************************************************************************
	*******************************************************************************/
	public int entriesCount()
	{
		return m_EntriesCount;
	}

	/*******************************************************************************
	*******************************************************************************/
	public boolean hasEntries()
	{
		return !m_Map.isEmpty();
	}
	
	/*******************************************************************************
	*******************************************************************************/
	public Set<String> getCategories()
	{
		return m_Map.keySet();
	}

	/*******************************************************************************
	*******************************************************************************/
	public List<ItemIF> getCategoryEntries( String inCategoryName)
	{
		return m_Map.get(inCategoryName);
	}

	/*******************************************************************************
		(AGR) 5 June 2005 - made synchronized.
	*******************************************************************************/
	public synchronized void clearTable()
	{
		if ( m_ExpiryTimer != null)
		{
			s_Headlines_Logger.info("CategoriesTable: cancelling Timer: " + m_ExpiryTimer);

			m_ExpiryTimer.cancel();
			m_ExpiryTimer = null;
		}

		m_ExpiryTask = null;

		/////////////////////////////////////

		if ( m_Map != null)
		{
			m_Map.clear();
		}

		m_EntriesCount = 0;
	}

	/*******************************************************************************
		(AGR) 5 June 2005 - made synchronized.
	*******************************************************************************/
	private synchronized void calculateCounts()
	{
		if (m_Map.isEmpty())
		{
			m_MinEntryCount = m_MaxEntryCount = 0;
			return;
		}
		
		//////////////////////////////////////////////////////////////////////

		m_MinEntryCount = Integer.MAX_VALUE;
		m_MaxEntryCount = 0;

		for ( List l : m_Map.values())
		{
			if ( l.size() > m_MaxEntryCount)
			{
				m_MaxEntryCount = l.size();
			}
			else if ( l.size() < m_MinEntryCount)
			{
				m_MinEntryCount = l.size();
			}
		}
	}

	/*******************************************************************************
	*******************************************************************************/
	public int getFontSize( int inCount, int inMinFontSize, int inDefaultSize, int inMaxFontSize)
	{
		if ( m_MinEntryCount >= m_MaxEntryCount)	// well, could have just said ==
		{
			return inDefaultSize;
		}

		if ( inCount >= m_MaxEntryCount)
		{
			return inMaxFontSize;
		}

		if ( inCount <= m_MinEntryCount)
		{
			return inMinFontSize;
		}

		double	d = (double) inCount / (double)( m_MaxEntryCount - m_MinEntryCount) * (double)( inMaxFontSize - inMinFontSize);

		return (int) Math.round( d + (double) inMinFontSize);
	}

	/*******************************************************************************
	*******************************************************************************/
	public String toString()
	{
		StringBuilder	sb = new StringBuilder(2000);

		sb.append("Entries: " + m_EntriesCount + "\n");

		for ( String theKey : m_Map.keySet())
		{
			List<ItemIF>	theEntries = m_Map.get(theKey);
			boolean		gotOne = false;

			for ( ItemIF theItem : theEntries)
			{
				if (!gotOne)
				{
					sb.append( theKey + " (" + theEntries.size() + ") : " + theItem + "\n");
					gotOne = true;
				}
				else
				{
					sb.append("                 " + theItem + "\n");
				}
			}
		}

		return sb.toString();
	}

	/********************************************************************
	********************************************************************/
	public class CategoryNameSorter implements Comparator<String>
	{
		/********************************************************************
		********************************************************************/
		public int compare( String a, String b)
		{
			return a.compareToIgnoreCase(b);
		}
	}

	/*******************************************************************************
		(AGR) 20 May 2005
	*******************************************************************************/
	class ExpiryTask extends ItemCleanerTask
	{
		/*******************************************************************************
		*******************************************************************************/
		public ExpiryTask( long inMaxItemAgeMS)
		{
			super(inMaxItemAgeMS);
		}

		/*******************************************************************************
		*******************************************************************************/
		public void run()
		{
			// info("<<< Cleaning old Category items >>> " + this);

			//////////////////////////////////////////////////////////////
			
			List<String>	theEmptyCats = null;
			List<ItemIF>	tempRemovalList = new ArrayList<ItemIF>(10);
			long		currMS = System.currentTimeMillis();

			for ( String theKey : m_Map.keySet())
			{
				List<ItemIF>	theEntries = m_Map.get(theKey);

				tempRemovalList.clear();

				for ( ItemIF theItem : theEntries)
				{
					if (isOutOfDate( currMS, theItem))
					{
						// info(".... age = " + UDates.getFormattedTimeDiff( currMS - FeedUtils.getItemDate(theItem).getTime()));

						tempRemovalList.add(theItem);
					}
				}

				if ( tempRemovalList.size() > 0)
				{
					info("  Expired items " + tempRemovalList + " for category \"" + theKey + "\"");
					// info("WAS: " + theEntries);

					theEntries.removeAll(tempRemovalList);
					if ( theEntries.size() < 1)
					{
						if ( theEmptyCats == null)
							theEmptyCats = new ArrayList<String>();

						theEmptyCats.add(theKey);
					}

					// info("NOW: " + theEntries);
					// info("===================================");
				}
			}

			////////////////////////////////////////////////////////

			if ( theEmptyCats != null)
			{
				// s_Headlines_Logger.info("... map was " + m_Map.keySet());

				for ( String theCatName : theEmptyCats)
				{
					info("  => Remove category \"" + theCatName + "\"");

					m_Map.remove(theCatName);
				}

				// s_Headlines_Logger.info("... map is  " + m_Map.keySet());
			}
		}
	}

	/*******************************************************************************
		(AGR) 19 May 2005. Calculate count in FeedList
		(AGR) 22 June 2005. Changed to be Observer
	*******************************************************************************/
	private static class CountEvent implements Observer
	{
		/*******************************************************************************
		*******************************************************************************/
		public void update( Observable o, Object arg)
		{
			CategoriesTable	theCatsTable = CategoriesTable.getInstance();
			theCatsTable.calculateCounts();

			////////////////////////////////////////////////////////

/*			List<RankingObject>		theRankingList = new ArrayList<RankingObject>();

			for ( String theCatName : theCatsTable.getCategories())
			{
				theRankingList.add( new RankingObject( theCatName, theCatsTable.m_Map.get(theCatName).size() ) );
			}

			java.util.Collections.sort(theRankingList);

			s_Headlines_Logger.info("Ranked list: " + theRankingList);
*/		}
	}

	/*******************************************************************************
		(AGR) 15 Jan 2006
	*******************************************************************************/
	private static class RankingObject implements Comparable<RankingObject>
	{
		public String	m_Key;
		public int	m_Score;

		/*******************************************************************************
		*******************************************************************************/
		public RankingObject( String inKey, int inScore)
		{
			m_Key = inKey;
			m_Score = inScore;
		}

		/*******************************************************************************
		*******************************************************************************/
		public int compareTo( RankingObject inOther)
		{
			if ( m_Score > inOther.m_Score)
			{
				return -1;
			}

			if ( m_Score < inOther.m_Score)
			{
				return 1;
			}

			return m_Key.compareTo( inOther.m_Key );
		}

		/*******************************************************************************
		*******************************************************************************/
		public String toString()
		{
			StringBuilder	sb = new StringBuilder();
			sb.append( m_Key ).append(" [").append(m_Score).append("]");
			return sb.toString();
		}
	}
}
