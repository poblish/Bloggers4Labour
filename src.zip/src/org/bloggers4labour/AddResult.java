/*
 * AddResult.java
 *
 * Created on 03 March 2006, 00:37
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour;

/**
 *
 * @author andrewre
 */
public enum AddResult	// (AGR) 27 May 2005
{
	SUCCEEDED, FAILED_NO_DATE, FAILED_GENERAL, FAILED_BAD_DATE, FAILED_DUPLICATE;
}