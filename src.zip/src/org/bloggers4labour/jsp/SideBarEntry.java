/*
 * SideBarEntry.java
 *
 * Created on 29 May 2006, 15:32
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.jsp;

/**
 *
 * @author andrewre
 */
public 	class SideBarEntry
{
	public String	name, url;

	public SideBarEntry( String x, String y)
	{
		name = x;
		url = y;
	}
};