/*
 * DataSourceManager.java
 *
 * Created on 19 February 2006, 11:24
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.bloggers4labour.sql;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.util.HashMap;
import javax.sql.DataSource;

/**
 *
 * @author andrewre
 */
public class DataSourceManager
{
	private HashMap<String,DataSource>	m_Map = new HashMap<String,DataSource>();

	private final static String		DEFAULT_SURCE = "bloggers4labour";

	/*******************************************************************************
	*******************************************************************************/
	private DataSourceManager()
	{
		MysqlDataSource	localSource = new MysqlDataSource();
		localSource.setUrl("jdbc:mysql://localhost:3306/Bloggers4Labour?user=root&password=Militant&useUnicode=true");
		register( DEFAULT_SURCE, localSource);
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized void register( String inName, DataSource inDataSource)
	{
		m_Map.put( inName, inDataSource);
	}

	/*******************************************************************************
	*******************************************************************************/
	public static DataSource getDefaultDataSource()
	{
		return getInstance().getDataSource( DEFAULT_SURCE );
	}

	/*******************************************************************************
	*******************************************************************************/
	public synchronized DataSource getDataSource( String inName)
	{
		return m_Map.get(inName);
	}

	/*******************************************************************************
	*******************************************************************************/
	public static DataSourceManager getInstance()
	{
		return LazyHolder.s_Mgr;
	}

	/*******************************************************************************
		(AGR) 5 June 2005. See:
		    <http://www-106.ibm.com/developerworks/java/library/j-jtp03304/>
	*******************************************************************************/
	private static class LazyHolder
	{
		private static DataSourceManager	s_Mgr = new DataSourceManager();
	}
}
